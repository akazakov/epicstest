host poplar
user tyoma
ioc start IOCNAME 
ioc_command ABC
run_command 
check something  
run another command 
check 
com 
check
com 
check

