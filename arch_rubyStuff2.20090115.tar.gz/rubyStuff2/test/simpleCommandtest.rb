require '../EPICSTestUtils.rb'

config = EPICSTestUtils::Cfg.load("test.cfg")

